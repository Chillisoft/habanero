
// ------------------------------------------------------------------------------
// This class was auto-generated for use with the Habanero Enterprise Framework.
// ------------------------------------------------------------------------------

namespace MachineExample.BO
{
    using System;
    using Habanero.BO;
    
    
    public partial class MachineProperty
    {
    }
}
